import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { WhyChooseUs } from './components/WhyChooseUs';
import { BmiCalculator } from './components/BmiCalculator';
import { MembershipCta } from './components/MembershipCta';
import { Reviews } from './components/Reviews';
import { LocationHours } from './components/LocationHours';
import { ContactForm } from './components/ContactForm';
import { Footer } from './components/Footer';
import { EnquiryModal } from './components/EnquiryModal';
import { CallModal } from './components/CallModal';

export default function App() {
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [selectedServiceOrPlan, setSelectedServiceOrPlan] = useState<string>('General Membership');
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [callModalMode, setCallModalMode] = useState<'call' | 'whatsapp'>('call');

  const handleOpenJoinModal = (serviceOrPlan?: string) => {
    if (serviceOrPlan) {
      setSelectedServiceOrPlan(serviceOrPlan);
    } else {
      setSelectedServiceOrPlan('General Membership');
    }
    setIsJoinModalOpen(true);
  };

  const handleOpenCallModal = () => {
    setCallModalMode('call');
    setIsCallModalOpen(true);
  };

  const handleOpenWhatsAppModal = () => {
    setCallModalMode('whatsapp');
    setIsCallModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0b0b0e] text-neutral-100 flex flex-col font-sans selection:bg-red-600 selection:text-white">
      {/* 3-Zone Top Navigation Bar */}
      <Navbar
        onOpenJoinModal={handleOpenJoinModal}
        onOpenCallModal={handleOpenCallModal}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero onOpenJoinModal={() => handleOpenJoinModal('General Membership')} />

        {/* About Section */}
        <About onOpenJoinModal={() => handleOpenJoinModal('General Membership')} />

        {/* Services Section with All 8 Services */}
        <Services onEnquireService={(serviceName) => handleOpenJoinModal(serviceName)} />

        {/* Why Choose Us Section with All 6 Pillars */}
        <WhyChooseUs />

        {/* Interactive BMI & Goal Assessment Tool */}
        <BmiCalculator onSelectService={(serviceName) => handleOpenJoinModal(serviceName)} />

        {/* Membership CTA Section */}
        <MembershipCta onOpenJoinModal={handleOpenJoinModal} />

        {/* Verified 4.0 Star Google Reviews Section */}
        <Reviews />

        {/* Embedded Location & Operating Hours */}
        <LocationHours
          onOpenCallModal={handleOpenCallModal}
          onOpenWhatsAppModal={handleOpenWhatsAppModal}
        />

        {/* Contact Information & Enquiry Form */}
        <ContactForm
          onOpenCallModal={handleOpenCallModal}
          onOpenWhatsAppModal={handleOpenWhatsAppModal}
        />
      </main>

      {/* Footer */}
      <Footer
        onOpenCallModal={handleOpenCallModal}
        onOpenWhatsAppModal={handleOpenWhatsAppModal}
      />

      {/* Interactive Joining/Enquiry Modal */}
      <EnquiryModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
        initialServiceOrPlan={selectedServiceOrPlan}
      />

      {/* Interactive Call / WhatsApp Dialog */}
      <CallModal
        isOpen={isCallModalOpen}
        onClose={() => setIsCallModalOpen(false)}
        defaultMode={callModalMode}
      />
    </div>
  );
}
