export interface ServiceItem {
  id: string;
  name: string;
  category: 'strength' | 'cardio' | 'coaching' | 'wellness';
  description: string;
  duration: string;
  suitableFor: string;
  image: string;
  highlights: string[];
}

export interface ReviewItem {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verifiedMember: boolean;
}

export interface OpeningHourItem {
  day: string;
  hours: string;
  isToday?: boolean;
}

export interface WhyChooseItem {
  id: string;
  title: string;
  description: string;
  badge: string;
}
