import React, { useState } from 'react';
import {
  Phone,
  MessageCircle,
  MapPin,
  Send,
  CheckCircle2,
  Building,
  Clock,
  Sparkles,
  Copy,
  Check,
} from 'lucide-react';
import { GYM_DETAILS, SERVICES_LIST } from '../data/gymData';

interface ContactFormProps {
  onOpenCallModal: () => void;
  onOpenWhatsAppModal: () => void;
}

export const ContactForm: React.FC<ContactFormProps> = ({
  onOpenCallModal,
  onOpenWhatsAppModal,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('Weight Training');
  const [timing, setTiming] = useState('Morning (06:00 AM – 10:00 AM)');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [copiedPlaceholder, setCopiedPlaceholder] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    setSubmitted(true);
  };

  const handleCopyPlaceholder = () => {
    navigator.clipboard.writeText(GYM_DETAILS.contact.phonePlaceholder);
    setCopiedPlaceholder(true);
    setTimeout(() => setCopiedPlaceholder(false), 2000);
  };

  const handleGetDirections = () => {
    window.open(GYM_DETAILS.location.mapsUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-24 bg-[#0b0b0e] border-t border-neutral-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Official Gym Contact Info & Direct Actions */}
          <div className="lg:col-span-5">
            <span className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-2 block">
              Direct Contact &amp; Enquiries
            </span>
            
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight mb-4">
              Get in Touch with VS FITNESS
            </h2>

            <p className="text-neutral-400 text-sm leading-relaxed mb-8">
              Ready to embark on your fitness journey? Visit our facility at Committee Chowk or send your enquiry below.
              Our coaches are ready to guide your training regimen.
            </p>

            {/* Official Address Card */}
            <div className="rounded-2xl bg-neutral-900/80 border border-neutral-800 p-6 mb-6 space-y-4">
              <div className="flex items-start gap-3">
                <Building className="w-5 h-5 text-red-500 shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg font-bold text-white font-heading">
                    {GYM_DETAILS.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mt-1">
                    {GYM_DETAILS.location.street}
                    <br />
                    {GYM_DETAILS.location.area}, {GYM_DETAILS.location.city}
                    <br />
                    {GYM_DETAILS.location.state} {GYM_DETAILS.location.pincode}, {GYM_DETAILS.location.country}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  <span>Open · Closes at {GYM_DETAILS.hours.closesAt}</span>
                </span>
                <span className="font-mono text-neutral-500">Motihari 845401</span>
              </div>
            </div>

            {/* Phone & WhatsApp Placeholders */}
            <div className="rounded-2xl bg-neutral-900/60 border border-neutral-800 p-5 mb-8 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-red-500" />
                  <span className="text-xs font-semibold text-neutral-300">Official Phone:</span>
                  <code className="text-xs text-red-400 font-mono bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
                    {GYM_DETAILS.contact.phonePlaceholder}
                  </code>
                </div>
                <button
                  onClick={handleCopyPlaceholder}
                  className="text-neutral-400 hover:text-white p-1"
                  title="Copy placeholder"
                >
                  {copiedPlaceholder ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-semibold text-neutral-300">Official WhatsApp:</span>
                  <code className="text-xs text-emerald-400 font-mono bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
                    {GYM_DETAILS.contact.whatsappPlaceholder}
                  </code>
                </div>
              </div>
            </div>

            {/* 3 Core Contact Action Buttons as requested */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={onOpenCallModal}
                className="flex items-center justify-center gap-2 py-3 px-4 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-red-950/40"
              >
                <Phone className="w-4 h-4" />
                <span>Call Now</span>
              </button>

              <button
                onClick={onOpenWhatsAppModal}
                className="flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-emerald-950/40"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>

              <button
                onClick={handleGetDirections}
                className="flex items-center justify-center gap-2 py-3 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-bold text-xs uppercase tracking-wider rounded-xl transition-all border border-neutral-700"
              >
                <MapPin className="w-4 h-4 text-red-500" />
                <span>Get Directions</span>
              </button>
            </div>
          </div>

          {/* Right Column: Contact / Enquiry Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-7 sm:p-9 shadow-2xl">
              <div className="mb-6 pb-4 border-b border-neutral-800">
                <h3 className="text-xl sm:text-2xl font-bold text-white font-heading mb-1">
                  Membership &amp; Training Enquiry
                </h3>
                <p className="text-xs text-neutral-400">
                  Fill in your preferred workout timing and service. We will connect with you with complete joining guidance.
                </p>
              </div>

              {submitted ? (
                <div className="py-10 text-center space-y-4 animate-in fade-in">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-xl font-bold text-white font-heading">
                    Enquiry Received Successfully!
                  </h4>
                  <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                    Thank you, <strong className="text-white">{name}</strong>. Your enquiry for{' '}
                    <strong className="text-red-400">{service}</strong> ({timing}) has been noted for VS FITNESS Committee Chowk, Motihari.
                  </p>
                  
                  <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
                    <button
                      onClick={() => {
                        const text = encodeURIComponent(
                          `Hello VS FITNESS! My name is ${name}. I am inquiring about ${service} (${timing}).`
                        );
                        window.open(`https://wa.me/?text=${text}`, '_blank');
                      }}
                      className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Send to WhatsApp</span>
                    </button>
                    <button
                      onClick={() => {
                        setSubmitted(false);
                        setName('');
                        setPhone('');
                        setMessage('');
                      }}
                      className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs rounded-xl"
                    >
                      Submit Another Enquiry
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Name */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Rahul Sharma"
                        className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                      />
                    </div>

                    {/* Phone */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                        Phone / WhatsApp *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="e.g. +91 98765 43210"
                        className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Service */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                        Desired Service
                      </label>
                      <select
                        value={service}
                        onChange={(e) => setService(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                      >
                        <option value="General Gym Membership">General Gym Membership</option>
                        {SERVICES_LIST.map((s) => (
                          <option key={s.id} value={s.name}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Preferred Timing */}
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                        Preferred Training Shift
                      </label>
                      <select
                        value={timing}
                        onChange={(e) => setTiming(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                      >
                        <option value="Morning (05:30 AM – 10:00 AM)">Morning (05:30 AM – 10:00 AM)</option>
                        <option value="Mid-day (11:00 AM – 03:00 PM)">Mid-day (11:00 AM – 03:00 PM)</option>
                        <option value="Evening (04:00 PM – 10:00 PM)">Evening (04:00 PM – 10:00 PM)</option>
                        <option value="Flexible / Weekend Only">Flexible / Weekend Only</option>
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                      Message / Fitness Goals (Optional)
                    </label>
                    <textarea
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Mention any specific goals like weight loss, muscle gain, personal trainer inquiry..."
                      className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-red-950/40"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Membership Enquiry</span>
                  </button>

                  <p className="text-[11px] text-neutral-500 text-center">
                    Your details are securely kept. We never spam. Located at Committee Chowk, Chhatauni, Motihari.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
