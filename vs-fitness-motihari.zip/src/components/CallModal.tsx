import React, { useState } from 'react';
import { X, Phone, MessageCircle, Copy, Check, MapPin, ExternalLink } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'call' | 'whatsapp';
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'call',
}) => {
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedWhatsApp, setCopiedWhatsApp] = useState(false);
  const [callbackName, setCallbackName] = useState('');
  const [callbackPhone, setCallbackPhone] = useState('');
  const [callbackSubmitted, setCallbackSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(GYM_DETAILS.contact.phonePlaceholder);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleCopyWhatsApp = () => {
    navigator.clipboard.writeText(GYM_DETAILS.contact.whatsappPlaceholder);
    setCopiedWhatsApp(true);
    setTimeout(() => setCopiedWhatsApp(false), 2000);
  };

  const handleDial = () => {
    window.location.href = `tel:${GYM_DETAILS.contact.phonePlaceholder}`;
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(GYM_DETAILS.contact.whatsappMessage);
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const handleCallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!callbackName || !callbackPhone) return;
    setCallbackSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0e0e12] border border-neutral-800 rounded-2xl p-6 sm:p-7 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-8 h-8 rounded-lg bg-red-600/20 text-red-500 flex items-center justify-center">
              {defaultMode === 'call' ? <Phone className="w-4 h-4" /> : <MessageCircle className="w-4 h-4 text-emerald-400" />}
            </span>
            <h3 className="text-xl font-bold text-white font-heading">
              Contact VS FITNESS
            </h3>
          </div>
          <p className="text-xs text-neutral-400">
            Committee Chowk, Near Dhaka Road, Chhatauni, Motihari
          </p>
        </div>

        {/* Contact Numbers Display with Copy Buttons */}
        <div className="space-y-3 mb-6">
          {/* Phone */}
          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-red-500" />
              <div>
                <span className="text-[11px] text-neutral-400 block uppercase font-medium">Gym Phone Number</span>
                <span className="text-sm font-bold text-white font-mono">{GYM_DETAILS.contact.phonePlaceholder}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopyPhone}
                className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-lg transition-colors"
                title="Copy phone"
              >
                {copiedPhone ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                onClick={handleDial}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition-colors"
              >
                Call
              </button>
            </div>
          </div>

          {/* WhatsApp */}
          <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-[11px] text-neutral-400 block uppercase font-medium">Official WhatsApp</span>
                <span className="text-sm font-bold text-white font-mono">{GYM_DETAILS.contact.whatsappPlaceholder}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopyWhatsApp}
                className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-lg transition-colors"
                title="Copy WhatsApp number"
              >
                {copiedWhatsApp ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                onClick={handleWhatsApp}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-colors"
              >
                Chat
              </button>
            </div>
          </div>
        </div>

        {/* Quick Callback Request */}
        <div className="pt-4 border-t border-neutral-800">
          <span className="text-xs font-semibold text-neutral-300 block mb-2">
            Or Request a Front Desk Callback
          </span>

          {callbackSubmitted ? (
            <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-center text-xs text-emerald-300">
              Request recorded for {callbackName}. Our Motihari desk will connect with you during operational hours (closes at 10 PM).
            </div>
          ) : (
            <form onSubmit={handleCallbackSubmit} className="space-y-2.5">
              <input
                type="text"
                required
                value={callbackName}
                onChange={(e) => setCallbackName(e.target.value)}
                placeholder="Your Name"
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
              <input
                type="tel"
                required
                value={callbackPhone}
                onChange={(e) => setCallbackPhone(e.target.value)}
                placeholder="Your Phone Number"
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold rounded-xl transition-colors"
              >
                Request Callback
              </button>
            </form>
          )}
        </div>

        <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-500">
          <span>Open Daily until 10:00 PM</span>
          <a
            href={GYM_DETAILS.location.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-red-400 hover:underline"
          >
            <MapPin className="w-3 h-3" />
            <span>View on Maps</span>
          </a>
        </div>
      </div>
    </div>
  );
};
