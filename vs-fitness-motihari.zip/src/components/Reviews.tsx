import React, { useState } from 'react';
import { Star, MessageSquare, ExternalLink, CheckCircle } from 'lucide-react';
import { GYM_DETAILS, GOOGLE_REVIEWS_DATA } from '../data/gymData';

export const Reviews: React.FC = () => {
  const [showReviewPrompt, setShowReviewPrompt] = useState(false);

  const handleRateOnGoogle = () => {
    // Open Google search with query for VS FITNESS Motihari reviews
    const query = encodeURIComponent('VS FITNESS Committee Chowk Chhatauni Motihari reviews');
    window.open(`https://www.google.com/search?q=${query}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="reviews" className="py-24 bg-[#0b0b0e] border-t border-neutral-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Rating Score Banner */}
        <div className="rounded-2xl bg-neutral-900/80 border border-neutral-800 p-8 sm:p-12 mb-14 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-6">
            {/* Big 4.0 Score Box */}
            <div className="flex flex-col items-center justify-center w-28 h-28 rounded-2xl bg-gradient-to-br from-neutral-800 to-neutral-950 border border-neutral-700/80 shadow-inner">
              <span className="text-4xl font-extrabold text-white font-mono leading-none">
                {GYM_DETAILS.rating.score.toFixed(1)}
              </span>
              <div className="flex items-center gap-0.5 mt-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${
                      i < Math.floor(GYM_DETAILS.rating.score)
                        ? 'text-amber-400 fill-amber-400'
                        : 'text-neutral-600'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-1">
                Verified Member Reputation
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white font-heading">
                4.0 ★ on Google
              </h2>
              <p className="text-sm text-neutral-400 mt-1">
                Based on <strong className="text-neutral-200">{GYM_DETAILS.rating.totalReviews} Google reviews</strong> from fitness members in Motihari and Chhatauni.
              </p>
              <div className="mt-3 flex items-center gap-2 text-xs text-neutral-400">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>Genuine reviews verified on Google Business profile</span>
              </div>
            </div>
          </div>

          {/* Action: Rate & Review on Google Button as requested */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            <button
              onClick={handleRateOnGoogle}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-red-950/40 hover:-translate-y-0.5"
            >
              <Star className="w-4 h-4 fill-white" />
              <span>Rate &amp; Review on Google</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowReviewPrompt(true)}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs rounded-xl transition-all"
            >
              <MessageSquare className="w-4 h-4 text-neutral-400" />
              <span>Member Experience</span>
            </button>
          </div>
        </div>

        {/* Reviews Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {GOOGLE_REVIEWS_DATA.map((review) => (
            <div
              key={review.id}
              className="rounded-2xl bg-neutral-900/60 border border-neutral-800 p-6 flex flex-col justify-between hover:border-neutral-700 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < review.rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-neutral-700'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[11px] text-neutral-500 font-medium">Google</span>
                </div>

                <p className="text-neutral-300 text-xs sm:text-sm leading-relaxed mb-4 italic">
                  &ldquo;{review.comment}&rdquo;
                </p>
              </div>

              <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                <span className="font-semibold text-white">{review.author}</span>
                <span className="text-[11px] text-neutral-400">{review.date}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Review modal info */}
        {showReviewPrompt && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="bg-neutral-900 border border-neutral-700 rounded-2xl max-w-md w-full p-6 text-center">
              <h3 className="text-lg font-bold text-white font-heading mb-2">
                We Value Your Feedback
              </h3>
              <p className="text-xs text-neutral-300 leading-relaxed mb-6">
                Are you an active or past member of VS FITNESS at Committee Chowk, Motihari?
                Your honest rating helps fellow fitness enthusiasts discover our gym.
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => setShowReviewPrompt(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    setShowReviewPrompt(false);
                    handleRateOnGoogle();
                  }}
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl"
                >
                  Write Review on Google
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
