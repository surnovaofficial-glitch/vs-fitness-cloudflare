import React from 'react';
import {
  Award,
  Layers,
  HeartHandshake,
  Dumbbell,
  Salad,
  Clock,
  Check,
} from 'lucide-react';
import { WHY_CHOOSE_US_ITEMS } from '../data/gymData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (id: string) => {
    switch (id) {
      case 'professional-training':
        return Award;
      case 'modern-environment':
        return Dumbbell;
      case 'personal-attention':
        return HeartHandshake;
      case 'multiple-programs':
        return Layers;
      case 'nutrition-guidance':
        return Salad;
      case 'flexible-options':
        return Clock;
      default:
        return Dumbbell;
    }
  };

  return (
    <section id="why-us" className="py-24 bg-[#0e0e12] border-t border-neutral-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-2 block">
            The VS FITNESS Standard
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight mb-4">
            Why Choose VS FITNESS?
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
            We provide a world-class training atmosphere right here in Motihari, combining certified coaching,
            state-of-the-art strength machinery, and an inclusive culture where results thrive.
          </p>
        </div>

        {/* 6 Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_CHOOSE_US_ITEMS.map((item, index) => {
            const Icon = getIcon(item.id);
            return (
              <div
                key={item.id}
                className="relative rounded-2xl bg-neutral-900/80 border border-neutral-800 p-7 hover:border-red-600/50 hover:bg-neutral-900 transition-all duration-300 group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 rounded-xl bg-red-600/15 text-red-500 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors duration-300">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-mono text-neutral-500 font-semibold">
                      0{index + 1}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white font-heading mb-2.5 group-hover:text-red-400 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-neutral-400 text-sm leading-relaxed mb-4">
                    {item.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-neutral-800/80 flex items-center gap-2 text-xs text-neutral-300 font-medium">
                  <Check className="w-3.5 h-3.5 text-red-500" />
                  <span>{item.badge}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Highlight Banner */}
        <div className="mt-14 rounded-2xl bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-900 border border-neutral-800 p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-xl">
            <h4 className="text-lg font-bold text-white font-heading mb-1">
              Serving Motihari with Uncompromised Equipment Quality
            </h4>
            <p className="text-xs sm:text-sm text-neutral-400">
              Clean rubberized flooring, sanitized locker sections, cold purified water, and an electrifying workout playlist to keep your energy peaked.
            </p>
          </div>
          <div className="shrink-0 flex items-center gap-3 text-xs sm:text-sm font-semibold text-neutral-300">
            <span className="px-3.5 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-red-400">
              Open 7 Days a Week
            </span>
            <span className="px-3.5 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-emerald-400">
              Closes at 10:00 PM
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
