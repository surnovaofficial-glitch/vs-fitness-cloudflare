import React from 'react';
import { CheckCircle2, Shield, HeartPulse, Users, Target, ArrowRight } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface AboutProps {
  onOpenJoinModal: () => void;
}

export const About: React.FC<AboutProps> = ({ onOpenJoinModal }) => {
  const pillars = [
    {
      icon: Target,
      title: 'Progressive Strength & Fitness',
      description: 'Engineered workout routines designed to build genuine physical strength, endurance, and functional muscle tone.',
    },
    {
      icon: HeartPulse,
      title: 'Healthy Lifestyle Transformation',
      description: 'Beyond lifting weights, we help you cultivate lifelong healthy habits, stamina, flexibility, and balanced nutritional awareness.',
    },
    {
      icon: Shield,
      title: 'Dedicated Personal Training',
      description: 'Hands-on certified trainers who tailor programming to your unique biomechanics, ensuring proper technique and injury prevention.',
    },
    {
      icon: Users,
      title: 'Welcoming & Motivated Community',
      description: 'An encouraging, respectful fitness environment in Chhatauni welcoming beginners, busy professionals, and experienced lifters alike.',
    },
  ];

  return (
    <section id="about" className="py-24 bg-[#0e0e12] border-t border-neutral-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Story & Narrative */}
          <div className="lg:col-span-7">
            <div className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-3">
              About VS FITNESS Motihari
            </div>
            
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight leading-tight mb-6">
              A Premier Professional Fitness Center in Motihari, Bihar
            </h2>

            <p className="text-neutral-300 text-base sm:text-lg leading-relaxed mb-6 font-light">
              Located conveniently at <strong className="text-white font-medium">Committee Chowk, Near Dhaka Road, Chhatauni</strong>,
              VS FITNESS was established to elevate fitness standards across Motihari. We believe that true physical transformation
              requires more than just gym machines—it demands an inspiring environment, disciplined guidance, and a supportive community.
            </p>

            <p className="text-neutral-400 text-sm sm:text-base leading-relaxed mb-8">
              Whether you are taking your very first step towards weight management, looking to conquer new personal records in weight training,
              or seeking high-energy CrossFit and calming Yoga sessions, our certified trainers provide the structure, personal attention,
              and encouragement you need to succeed.
            </p>

            {/* 4 Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {pillars.map((pillar) => {
                const IconComponent = pillar.icon;
                return (
                  <div
                    key={pillar.title}
                    className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80 hover:border-red-900/50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 mb-2">
                      <div className="w-7 h-7 rounded-lg bg-red-600/15 text-red-500 flex items-center justify-center">
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <h3 className="text-sm font-bold text-white tracking-wide">
                        {pillar.title}
                      </h3>
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      {pillar.description}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* CTA action */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenJoinModal}
                className="inline-flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold text-sm rounded-xl transition-all shadow-md shadow-red-900/40"
              >
                <span>Start Training With Us</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <a
                href="#location-hours"
                className="text-xs sm:text-sm text-neutral-300 hover:text-red-400 font-medium underline underline-offset-4 transition-colors"
              >
                Visit us at Committee Chowk, Chhatauni
              </a>
            </div>
          </div>

          {/* Right Column: Visual Showcase & Stat Highlights */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl group">
              <img
                src={GYM_DETAILS.assets.weights}
                alt="Strength training dumbbell racks and weight equipment at VS FITNESS Motihari"
                referrerPolicy="no-referrer"
                className="w-full h-[460px] object-cover object-center group-hover:scale-105 transition-transform duration-500 brightness-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-transparent to-transparent opacity-80" />

              {/* Overlay Stat Block */}
              <div className="absolute bottom-5 left-5 right-5 p-4 rounded-xl bg-neutral-900/90 backdrop-blur-md border border-neutral-700/80">
                <div className="grid grid-cols-3 divide-x divide-neutral-800 text-center">
                  <div className="px-2">
                    <span className="block text-xl sm:text-2xl font-extrabold text-red-500 font-display">8+</span>
                    <span className="text-[11px] text-neutral-400 uppercase tracking-wider">Programs</span>
                  </div>
                  <div className="px-2">
                    <span className="block text-xl sm:text-2xl font-extrabold text-white font-display">10 PM</span>
                    <span className="text-[11px] text-neutral-400 uppercase tracking-wider">Open Daily</span>
                  </div>
                  <div className="px-2">
                    <span className="block text-xl sm:text-2xl font-extrabold text-amber-400 font-display">4.0 ★</span>
                    <span className="text-[11px] text-neutral-400 uppercase tracking-wider">Google Rating</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Local Trust Note */}
            <div className="mt-4 flex items-center gap-2 text-xs text-neutral-400 justify-center lg:justify-start">
              <CheckCircle2 className="w-4 h-4 text-red-500 shrink-0" />
              <span>Serving fitness members across Chhatauni, Dhaka Road & Motihari</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
