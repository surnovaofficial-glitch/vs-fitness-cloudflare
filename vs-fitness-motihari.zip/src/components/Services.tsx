import React, { useState } from 'react';
import {
  Dumbbell,
  Flame,
  UserCheck,
  Apple,
  Sparkles,
  Activity,
  Trophy,
  Award,
  ArrowRight,
  Check,
} from 'lucide-react';
import { SERVICES_LIST } from '../data/gymData';
import { ServiceItem } from '../types';

interface ServicesProps {
  onEnquireService: (serviceName: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onEnquireService }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'weight-training':
        return Dumbbell;
      case 'crossfit':
        return Flame;
      case 'personal-training':
        return UserCheck;
      case 'nutrition-consulting':
        return Apple;
      case 'yoga-classes':
        return Sparkles;
      case 'aerobics':
        return Activity;
      case 'adult-sports':
        return Trophy;
      case 'private-lessons':
        return Award;
      default:
        return Dumbbell;
    }
  };

  const filteredServices =
    activeCategory === 'all'
      ? SERVICES_LIST
      : SERVICES_LIST.filter((s) => s.category === activeCategory);

  const categories = [
    { id: 'all', label: 'All Services (8)' },
    { id: 'strength', label: 'Strength & CrossFit' },
    { id: 'coaching', label: 'Personal Coaching' },
    { id: 'cardio', label: 'Cardio & Sports' },
    { id: 'wellness', label: 'Yoga & Recovery' },
  ];

  return (
    <section id="services" className="py-24 bg-[#0b0b0e] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div className="max-w-2xl">
            <span className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-2 block">
              Comprehensive Fitness Solutions
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight">
              Our Training Services
            </h2>
            <p className="text-neutral-400 text-sm sm:text-base mt-3">
              Explore specialized fitness disciplines led by passionate instructors in Motihari.
              Whether your goal is muscle hypertrophy, fat loss, flexibility, or athletic conditioning.
            </p>
          </div>

          {/* Interactive Filter Tabs (functional segmented control) */}
          <div className="mt-6 md:mt-0 flex flex-wrap gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded-xl">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  activeCategory === cat.id
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* 8 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredServices.map((service: ServiceItem) => {
            const IconComp = getServiceIcon(service.id);
            return (
              <div
                key={service.id}
                className="group flex flex-col justify-between rounded-2xl bg-neutral-900/70 border border-neutral-800 hover:border-red-600/60 overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-red-950/20"
              >
                <div>
                  {/* Card Image Banner */}
                  <div className="relative h-44 w-full overflow-hidden bg-neutral-950">
                    <img
                      src={service.image}
                      alt={`${service.name} at VS FITNESS Motihari`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500 brightness-85"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/30 to-transparent" />
                    
                    {/* Icon Badge */}
                    <div className="absolute bottom-3 left-4 w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-black/50">
                      <IconComp className="w-5 h-5" />
                    </div>

                    {/* Duration chip unboxed subtle */}
                    <div className="absolute top-3 right-3 text-[11px] font-medium text-neutral-300 bg-neutral-950/80 backdrop-blur px-2.5 py-1 rounded-md border border-neutral-800">
                      {service.duration}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5">
                    <h3 className="text-xl font-bold text-white font-heading mb-2 group-hover:text-red-400 transition-colors">
                      {service.name}
                    </h3>
                    <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed mb-4">
                      {service.description}
                    </p>

                    {/* Features list */}
                    <div className="space-y-1.5 pt-2 border-t border-neutral-800/80 mb-5">
                      {service.highlights.slice(0, 3).map((item) => (
                        <div key={item} className="flex items-center gap-2 text-xs text-neutral-300">
                          <Check className="w-3.5 h-3.5 text-red-500 shrink-0" />
                          <span className="truncate">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Action */}
                <div className="p-5 pt-0">
                  <button
                    onClick={() => onEnquireService(service.name)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-neutral-800 hover:bg-red-600 text-neutral-200 hover:text-white font-semibold text-xs rounded-xl transition-all duration-200 shadow-sm"
                  >
                    <span>Enquire Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Notice for visitors */}
        <div className="mt-12 text-center text-xs text-neutral-400">
          All programs are conducted at our Chhatauni facility under strict safety and hygiene standards. Need guidance on where to start?{' '}
          <button
            onClick={() => onEnquireService('General Fitness Consultation')}
            className="text-red-400 font-semibold underline underline-offset-4 hover:text-red-300"
          >
            Request a Free Consultation
          </button>
        </div>
      </div>
    </section>
  );
};
