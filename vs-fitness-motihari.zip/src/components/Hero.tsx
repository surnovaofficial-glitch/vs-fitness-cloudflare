import React from 'react';
import { ArrowRight, MapPin, Star, Clock, Compass, Dumbbell } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface HeroProps {
  onOpenJoinModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenJoinModal }) => {
  const handleGetDirections = () => {
    window.open(GYM_DETAILS.location.mapsUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 overflow-hidden bg-[#0b0b0e]">
      {/* Background Image with Dark Athletic Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={GYM_DETAILS.assets.hero}
          alt="Athletes training intensely at VS FITNESS gym Motihari"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center brightness-60 contrast-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0e] via-[#0b0b0e]/75 to-[#0b0b0e]/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0b0b0e] via-[#0b0b0e]/80 to-transparent" />
        {/* Subtle red accent glow */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          {/* Unboxed Metadata Trust Bar (Zero-Pill discipline) */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2 text-xs sm:text-sm text-neutral-300 mb-6 font-medium">
            <span className="flex items-center gap-1.5 text-red-400 font-semibold tracking-wide uppercase">
              <Dumbbell className="w-4 h-4" />
              Motihari, Bihar
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="flex items-center gap-1 text-amber-400 font-semibold">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              {GYM_DETAILS.rating.score.toFixed(1)} Rating ({GYM_DETAILS.rating.totalReviews} Google Reviews)
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Open · Closes at {GYM_DETAILS.hours.closesAt}
            </span>
          </div>

          {/* Main Gym Name & Hero Tagline */}
          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-extrabold uppercase tracking-tight text-white font-display leading-[0.95] mb-4">
            VS <span className="text-red-600 underline decoration-red-600/40 decoration-wavy">FITNESS</span>
          </h1>

          <p className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-100 font-heading tracking-tight mb-6 max-w-2xl">
            {GYM_DETAILS.tagline}
          </p>

          <p className="text-base sm:text-lg text-neutral-300 mb-9 leading-relaxed max-w-2xl font-light">
            Motihari&apos;s premier professional fitness center at Committee Chowk, Near Dhaka Road, Chhatauni.
            Equipped with top-tier strength machinery, Olympic weights, certified trainers, and dedicated zones
            for CrossFit, Aerobics, and Yoga.
          </p>

          {/* 3 Core Action Buttons as required */}
          <div className="flex flex-wrap items-center gap-3.5 sm:gap-4 mb-12">
            <button
              onClick={onOpenJoinModal}
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-sm sm:text-base rounded-xl transition-all duration-200 shadow-lg shadow-red-950/50 hover:shadow-red-700/30 hover:-translate-y-0.5"
            >
              <span>Join Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href="#services"
              className="inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-100 hover:text-white font-semibold text-sm sm:text-base border border-neutral-700 rounded-xl transition-all duration-200 hover:-translate-y-0.5"
            >
              <Compass className="w-4 h-4 text-red-500" />
              <span>Explore Services</span>
            </a>

            <button
              onClick={handleGetDirections}
              className="inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-100 hover:text-white font-semibold text-sm sm:text-base border border-neutral-700 rounded-xl transition-all duration-200 hover:-translate-y-0.5"
            >
              <MapPin className="w-4 h-4 text-red-500" />
              <span>Get Directions</span>
            </button>
          </div>

          {/* Quick Location & Status Snapshot */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6 border-t border-neutral-800/80 text-xs sm:text-sm text-neutral-400">
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <span className="text-neutral-200 font-medium block">Gym Location</span>
                <span>Committee Chowk, Near Dhaka Road, Chhatauni, Motihari 845401</span>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Clock className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <span className="text-neutral-200 font-medium block">Working Hours</span>
                <span>Monday – Sunday · Closes at {GYM_DETAILS.hours.closesAt}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
