import React from 'react';
import { Dumbbell, MapPin, Clock, Phone, MessageCircle, Instagram, Facebook, ArrowUp } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface FooterProps {
  onOpenCallModal: () => void;
  onOpenWhatsAppModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCallModal, onOpenWhatsAppModal }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const quickLinks = [
    { label: 'Home', href: '#' },
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Why Us', href: '#why-us' },
    { label: 'Calculator', href: '#calculator' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
    { label: 'Location', href: '#location-hours' },
  ];

  return (
    <footer className="bg-[#070709] border-t border-neutral-900 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Col 1: Brand & Bio */}
          <div className="lg:col-span-4 space-y-4">
            <a href="#" className="flex items-center gap-2 group">
              <span className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white shadow">
                <Dumbbell className="w-4 h-4" />
              </span>
              <span className="text-2xl font-extrabold tracking-wider text-white uppercase font-display">
                VS <span className="text-red-500">FITNESS</span>
              </span>
            </a>

            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              Motihari&apos;s leading fitness center located at Committee Chowk, Near Dhaka Road, Chhatauni.
              Dedicated to strength, health, bodybuilding, and active lifestyle transformation.
            </p>

            {/* Social media icons with placeholder handles */}
            <div className="pt-2">
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
                Social Profiles
              </span>
              <div className="flex items-center gap-3">
                <a
                  href="#contact"
                  title={`Instagram: ${GYM_DETAILS.contact.instagramPlaceholder}`}
                  className="w-8 h-8 rounded-lg bg-neutral-900 hover:bg-red-600 hover:text-white flex items-center justify-center transition-colors border border-neutral-800"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href="#contact"
                  title={`Facebook: ${GYM_DETAILS.contact.facebookPlaceholder}`}
                  className="w-8 h-8 rounded-lg bg-neutral-900 hover:bg-red-600 hover:text-white flex items-center justify-center transition-colors border border-neutral-800"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <button
                  onClick={onOpenWhatsAppModal}
                  title={`WhatsApp: ${GYM_DETAILS.contact.whatsappPlaceholder}`}
                  className="w-8 h-8 rounded-lg bg-neutral-900 hover:bg-emerald-600 hover:text-white flex items-center justify-center transition-colors border border-neutral-800"
                >
                  <MessageCircle className="w-4 h-4" />
                </button>
                <button
                  onClick={onOpenCallModal}
                  title={`Phone: ${GYM_DETAILS.contact.phonePlaceholder}`}
                  className="w-8 h-8 rounded-lg bg-neutral-900 hover:bg-red-600 hover:text-white flex items-center justify-center transition-colors border border-neutral-800"
                >
                  <Phone className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
              Quick Links
            </h4>
            <ul className="grid grid-cols-2 gap-2 text-xs">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-red-400 transition-colors py-0.5 inline-block"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>

            <div className="pt-3">
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 block mb-1">
                Local SEO Searches
              </span>
              <p className="text-[11px] text-neutral-500 leading-normal">
                Gym in Motihari · Best gym in Motihari · VS FITNESS Motihari · Gym near Chhatauni · Fitness center in Motihari
              </p>
            </div>
          </div>

          {/* Col 3: Address & Contact */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
              Address &amp; Contact
            </h4>
            <div className="space-y-2 text-xs leading-relaxed">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>
                  {GYM_DETAILS.location.street},<br />
                  {GYM_DETAILS.location.area}, {GYM_DETAILS.location.city},<br />
                  {GYM_DETAILS.location.state} {GYM_DETAILS.location.pincode}, India
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <Phone className="w-4 h-4 text-red-500 shrink-0" />
                <span>{GYM_DETAILS.contact.phonePlaceholder}</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{GYM_DETAILS.contact.whatsappPlaceholder}</span>
              </div>
            </div>
          </div>

          {/* Col 4: Opening Hours */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
              Opening Hours
            </h4>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <Clock className="w-3.5 h-3.5" />
                <span>Open Everyday</span>
              </div>
              <p className="text-neutral-300">
                Mon – Sat:
                <br />
                <span className="font-mono text-neutral-200">5:30 AM – 10:00 PM</span>
              </p>
              <p className="text-neutral-300">
                Sunday:
                <br />
                <span className="font-mono text-neutral-200">6:00 AM – 8:00 PM</span>
              </p>
              <p className="text-red-400 text-[11px] pt-1 font-medium">
                Closes at {GYM_DETAILS.hours.closesAt}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Back to Top */}
        <div className="mt-12 pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© 2026 VS FITNESS. All rights reserved. Committee Chowk, Chhatauni, Motihari, Bihar 845401.</p>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 text-neutral-400 hover:text-white transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
