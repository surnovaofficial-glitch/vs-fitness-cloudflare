import React from 'react';
import {
  MapPin,
  Clock,
  Navigation,
  Phone,
  MessageCircle,
  Building2,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface LocationHoursProps {
  onOpenCallModal: () => void;
  onOpenWhatsAppModal: () => void;
}

export const LocationHours: React.FC<LocationHoursProps> = ({
  onOpenCallModal,
  onOpenWhatsAppModal,
}) => {
  const currentDayIndex = new Date().getDay(); // 0 is Sunday, 1 is Monday ...
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const todayName = daysOfWeek[currentDayIndex];

  const handleGetDirections = () => {
    window.open(GYM_DETAILS.location.mapsUrl, '_blank', 'noopener,noreferrer');
  };

  // Google Maps embed URL centered on Committee Chowk, Chhatauni, Motihari, Bihar 845401
  const mapEmbedUrl = `https://maps.google.com/maps?q=Committee+Chowk,+Near+Dhaka+Road,+Chhatauni,+Motihari,+Bihar+845401&t=&z=16&ie=UTF8&iwloc=&output=embed`;

  return (
    <section id="location-hours" className="py-24 bg-[#0e0e12] border-t border-neutral-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-2 block">
            Visit Our Fitness Facility
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight mb-4">
            Location &amp; Operating Hours
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base">
            Conveniently situated at Committee Chowk in Chhatauni, Motihari with straightforward road connectivity and parking.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Address, Live Hours, and Schedule */}
          <div className="lg:col-span-5 space-y-6">
            {/* Live Status Card */}
            <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-6 shadow-xl">
              <div className="flex items-center justify-between mb-4 pb-4 border-b border-neutral-800">
                <div className="flex items-center gap-3">
                  <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 animate-pulse" />
                  <div>
                    <span className="text-sm font-bold text-white uppercase tracking-wider block">
                      Status: {GYM_DETAILS.hours.statusText}
                    </span>
                    <span className="text-xs text-emerald-400 font-medium">
                      Closes at {GYM_DETAILS.hours.closesAt} Today
                    </span>
                  </div>
                </div>

                <span className="text-xs font-mono text-neutral-400 px-2.5 py-1 bg-neutral-950 rounded-md border border-neutral-800">
                  {todayName}
                </span>
              </div>

              {/* Gym Location Details */}
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Building2 className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white text-base block font-heading">
                      {GYM_DETAILS.name}
                    </strong>
                    <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mt-0.5">
                      {GYM_DETAILS.location.street}
                      <br />
                      {GYM_DETAILS.location.area}, {GYM_DETAILS.location.city}, {GYM_DETAILS.location.state} {GYM_DETAILS.location.pincode}
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs text-neutral-400 space-y-1">
                  <div className="flex items-center gap-2 text-neutral-300 font-medium">
                    <CheckCircle className="w-3.5 h-3.5 text-red-500" />
                    <span>Landmark: Near Dhaka Road junction</span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-300 font-medium">
                    <CheckCircle className="w-3.5 h-3.5 text-red-500" />
                    <span>Easy two-wheeler &amp; car parking accessible</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Directions, Call, WhatsApp */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-6 pt-5 border-t border-neutral-800">
                <button
                  onClick={handleGetDirections}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-red-950/40"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Directions</span>
                </button>

                <button
                  onClick={onOpenCallModal}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-semibold text-xs rounded-xl transition-all"
                >
                  <Phone className="w-3.5 h-3.5 text-red-400" />
                  <span>Call Now</span>
                </button>

                <button
                  onClick={onOpenWhatsAppModal}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-semibold text-xs rounded-xl transition-all"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Weekly Schedule Table */}
            <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-6 shadow-xl">
              <div className="flex items-center gap-2 text-sm font-bold text-white uppercase tracking-wider mb-4">
                <Clock className="w-4 h-4 text-red-500" />
                <span>Weekly Training Schedule</span>
              </div>

              <div className="divide-y divide-neutral-800/80 text-xs">
                {GYM_DETAILS.hours.schedule.map((item) => {
                  const isCurrentDay = item.day.toLowerCase() === todayName.toLowerCase();
                  return (
                    <div
                      key={item.day}
                      className={`py-2.5 flex items-center justify-between ${
                        isCurrentDay ? 'text-red-400 font-bold bg-red-950/20 px-2 rounded-lg' : 'text-neutral-300'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {isCurrentDay && <span className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                        {item.day}
                      </span>
                      <span className="font-mono text-neutral-200">{item.hours}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Google Maps Embed */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 shadow-2xl relative">
              <div className="p-4 bg-neutral-900/90 border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold text-neutral-200">
                  <MapPin className="w-4 h-4 text-red-500" />
                  <span>Google Maps: Committee Chowk, Chhatauni, Motihari</span>
                </div>
                <button
                  onClick={handleGetDirections}
                  className="inline-flex items-center gap-1 text-[11px] text-red-400 hover:text-red-300 font-semibold"
                >
                  <span>Open in App</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

              {/* Embedded Google Maps Frame */}
              <div className="relative h-[480px] w-full bg-neutral-900">
                <iframe
                  title="VS FITNESS Motihari Location Map"
                  src={mapEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0, filter: 'contrast(102%) brightness(95%)' }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />
              </div>

              {/* Map Footer Bar */}
              <div className="p-3 bg-neutral-950 border-t border-neutral-800 text-[11px] text-neutral-400 flex flex-wrap items-center justify-between gap-2">
                <span>Coordinates: Committee Chowk, Motihari 845401</span>
                <span className="text-neutral-500">Search query: &quot;VS FITNESS Motihari&quot;</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
