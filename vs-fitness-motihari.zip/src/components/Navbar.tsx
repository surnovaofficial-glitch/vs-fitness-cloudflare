import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Dumbbell, MapPin, Clock } from 'lucide-react';
import { GYM_DETAILS } from '../data/gymData';

interface NavbarProps {
  onOpenJoinModal: (serviceOrPlan?: string) => void;
  onOpenCallModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenJoinModal, onOpenCallModal }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Why Us', href: '#why-us' },
    { label: 'Calculator', href: '#calculator' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Location & Hours', href: '#location-hours' },
  ];

  return (
    <>
      {/* Top Bar following 3-Zone Contract: [Brand title] — [Nav links] — [Primary action] */}
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0b0b0e]/95 backdrop-blur-md border-b border-neutral-800 shadow-xl py-3.5'
            : 'bg-gradient-to-b from-[#0b0b0e]/90 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Zone 1: Single text element wordmark */}
          <a
            href="#"
            className="flex items-center gap-2 group focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 rounded"
            aria-label="VS FITNESS Home"
          >
            <span className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-lg shadow-red-900/40 group-hover:scale-105 transition-transform duration-200">
              <Dumbbell className="w-5 h-5" />
            </span>
            <span className="text-2xl font-extrabold tracking-wider text-white uppercase font-display">
              VS <span className="text-red-500">FITNESS</span>
            </span>
          </a>

          {/* Zone 2: Clean 4-6 text navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-neutral-300">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-white hover:text-red-400 transition-colors duration-150 py-1"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={onOpenCallModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/80 rounded-lg transition-colors whitespace-nowrap"
            >
              <Phone className="w-3.5 h-3.5 text-red-400" />
              <span>Call Now</span>
            </button>
            <button
              onClick={() => onOpenJoinModal()}
              className="inline-flex items-center justify-center px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg transition-all duration-150 shadow-md shadow-red-900/30 whitespace-nowrap"
            >
              Join VS FITNESS
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={() => onOpenJoinModal()}
              className="px-3 py-1.5 text-xs font-bold text-white bg-red-600 rounded-md"
            >
              Join
            </button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-neutral-300 hover:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="fixed inset-x-0 top-[60px] z-30 bg-[#0d0d12]/98 border-b border-neutral-800 px-6 py-6 sm:hidden shadow-2xl backdrop-blur-xl animate-in slide-in-from-top duration-200">
          <div className="flex flex-col gap-4 text-base font-medium">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-neutral-200 hover:text-red-400 py-1.5 transition-colors border-b border-neutral-900"
              >
                {link.label}
              </a>
            ))}

            <div className="pt-2 text-xs text-neutral-400 flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-red-500" />
              <span>Committee Chowk, Chhatauni, Motihari</span>
            </div>

            <div className="text-xs text-neutral-400 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Open · Closes at {GYM_DETAILS.hours.closesAt}</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-3">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenCallModal();
                }}
                className="flex items-center justify-center gap-2 py-2.5 text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-neutral-100 border border-neutral-800 rounded-lg"
              >
                <Phone className="w-3.5 h-3.5 text-red-400" />
                <span>Call Now</span>
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenJoinModal();
                }}
                className="py-2.5 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg shadow"
              >
                Join Now
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
