import React from 'react';
import { Check, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { MEMBERSHIP_TIERS } from '../data/gymData';

interface MembershipCtaProps {
  onOpenJoinModal: (planName?: string) => void;
}

export const MembershipCta: React.FC<MembershipCtaProps> = ({ onOpenJoinModal }) => {
  return (
    <section id="membership" className="py-24 bg-[#0e0e12] border-t border-neutral-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main CTA Decision Block */}
        <div className="rounded-3xl bg-gradient-to-b from-neutral-900 via-neutral-900 to-[#0b0b0e] border border-neutral-800 p-8 sm:p-14 mb-20 text-center relative overflow-hidden shadow-2xl">
          {/* Subtle decorative glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-red-600/10 blur-3xl pointer-events-none" />

          <span className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-3 block">
            Begin Your Transformation Today
          </span>

          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white font-heading tracking-tight mb-5 max-w-3xl mx-auto">
            Ready to Start Your Fitness Journey?
          </h2>

          <p className="text-neutral-300 text-sm sm:text-base max-w-2xl mx-auto mb-8 font-light">
            Join VS FITNESS at Committee Chowk, Chhatauni, Motihari. Whether you need structured weight training,
            CrossFit conditioning, or personal attention from certified coaches, our doors are open for you.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onOpenJoinModal('General Membership')}
              className="inline-flex items-center gap-2.5 px-8 py-4 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-base rounded-xl transition-all shadow-xl shadow-red-950/60 hover:-translate-y-0.5"
            >
              <span>Join VS FITNESS</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-6 py-4 bg-neutral-950 hover:bg-neutral-800 text-neutral-200 hover:text-white font-semibold text-base border border-neutral-800 rounded-xl transition-all"
            >
              <span>Enquire at Desk</span>
            </a>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-neutral-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-red-500" />
              Certified Fitness Mentors
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-red-500" />
              Clean &amp; Ventilated Facility
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-red-500" />
              Open Daily Till 10:00 PM
            </span>
          </div>
        </div>

        {/* Membership Options Showcase */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-2 block">
            Flexible Registration Options
          </span>
          <h3 className="text-2xl sm:text-3xl font-bold text-white font-heading">
            Membership Programs
          </h3>
          <p className="text-neutral-400 text-xs sm:text-sm mt-2">
            Select a plan duration that matches your fitness ambitions. Contact desk for current seasonal promotions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {MEMBERSHIP_TIERS.map((tier) => (
            <div
              key={tier.id}
              className={`rounded-2xl flex flex-col justify-between p-6 transition-all duration-300 ${
                tier.popular
                  ? 'bg-neutral-900 border-2 border-red-600 shadow-xl shadow-red-950/30 relative'
                  : 'bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700'
              }`}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-red-600 text-white text-[11px] font-bold rounded-full uppercase tracking-wider flex items-center gap-1 shadow">
                  <Sparkles className="w-3 h-3" />
                  Most Popular
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-red-400 tracking-wide">
                    {tier.badge}
                  </span>
                  <span className="text-xs text-neutral-500 font-mono">
                    {tier.duration}
                  </span>
                </div>

                <h4 className="text-xl font-bold text-white font-heading mb-2">
                  {tier.name}
                </h4>

                <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                  {tier.description}
                </p>

                <div className="py-3 px-3.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-300 font-medium mb-6 text-center">
                  <span className="text-neutral-400 block text-[10px] uppercase tracking-wider mb-0.5">Membership Fee</span>
                  <span className="font-semibold text-white">{tier.pricePlaceholder}</span>
                </div>

                <div className="space-y-2 mb-6 text-xs text-neutral-300">
                  {tier.features.map((feat) => (
                    <div key={feat} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
                      <span className="leading-snug">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <button
                  onClick={() => onOpenJoinModal(tier.name)}
                  className={`w-full py-2.5 px-4 text-xs font-bold rounded-xl transition-all duration-200 ${
                    tier.popular
                      ? 'bg-red-600 hover:bg-red-700 text-white shadow-md shadow-red-950/40'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                  }`}
                >
                  Join / Enquire Plan
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
