import React, { useState, useEffect } from 'react';
import { X, Send, CheckCircle2, MessageCircle, Sparkles } from 'lucide-react';
import { SERVICES_LIST, GYM_DETAILS } from '../data/gymData';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialServiceOrPlan?: string;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({
  isOpen,
  onClose,
  initialServiceOrPlan = 'General Membership',
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedItem, setSelectedItem] = useState(initialServiceOrPlan);
  const [timing, setTiming] = useState('Morning (05:30 AM – 10:00 AM)');
  const [note, setNote] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (initialServiceOrPlan) {
      setSelectedItem(initialServiceOrPlan);
    }
    setSubmitted(false);
  }, [initialServiceOrPlan, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    setSubmitted(true);
  };

  const handleWhatsAppSend = () => {
    const text = encodeURIComponent(
      `Hello VS FITNESS! My name is ${name}. I want to join/enquire about ${selectedItem} (${timing}) at Committee Chowk, Motihari.`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0e0e12] border border-neutral-800 rounded-2xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold text-white font-heading">
              Enquiry Submitted!
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed max-w-sm mx-auto">
              Thank you, <strong className="text-white">{name}</strong>. Your interest in{' '}
              <strong className="text-red-400">{selectedItem}</strong> at VS FITNESS Motihari has been registered.
            </p>

            <div className="pt-4 flex flex-col gap-2.5">
              <button
                onClick={handleWhatsAppSend}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Instant Connect via WhatsApp</span>
              </button>
              <button
                onClick={onClose}
                className="w-full py-2.5 px-4 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <div className="text-xs font-semibold text-red-500 uppercase tracking-widest mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>VS FITNESS Motihari</span>
              </div>
              <h3 className="text-2xl font-bold text-white font-heading">
                Join or Enquire
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                Committee Chowk, Near Dhaka Road, Chhatauni, Motihari
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Selected Program / Membership
                </label>
                <select
                  value={selectedItem}
                  onChange={(e) => setSelectedItem(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500"
                >
                  <option value="General Membership">General Gym Membership</option>
                  <option value="Quarterly Transformation">Quarterly Transformation (90 Days)</option>
                  <option value="Annual VIP Pass">Annual VIP Pass (365 Days)</option>
                  <option value="Personal Training Program">Personal Training Program</option>
                  {SERVICES_LIST.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Ramesh Singh"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                    Phone / WhatsApp *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. +91 9876543210"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Preferred Training Slot
                </label>
                <select
                  value={timing}
                  onChange={(e) => setTiming(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500"
                >
                  <option value="Morning (05:30 AM – 10:00 AM)">Morning (05:30 AM – 10:00 AM)</option>
                  <option value="Mid-day (11:00 AM – 03:00 PM)">Mid-day (11:00 AM – 03:00 PM)</option>
                  <option value="Evening (04:00 PM – 10:00 PM)">Evening (04:00 PM – 10:00 PM)</option>
                  <option value="Anytime / Flexible">Anytime / Flexible</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Specific Questions / Fitness Goal (Optional)
                </label>
                <textarea
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Inquiring about timing, fee structure, beginner guidance..."
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-2 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-red-950/40"
              >
                <Send className="w-4 h-4" />
                <span>Submit Joining Enquiry</span>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
