import React, { useState } from 'react';
import { Calculator, ArrowRight, CheckCircle2, RotateCcw } from 'lucide-react';

interface BmiCalculatorProps {
  onSelectService: (serviceName: string) => void;
}

export const BmiCalculator: React.FC<BmiCalculatorProps> = ({ onSelectService }) => {
  const [height, setHeight] = useState<string>('172');
  const [weight, setWeight] = useState<string>('70');
  const [goal, setGoal] = useState<string>('muscle');
  const [result, setResult] = useState<{
    bmi: number;
    category: string;
    idealWeight: string;
    recommendedService: string;
    proteinSuggestion: string;
  } | null>(null);

  const calculateBmi = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const h = parseFloat(height);
    const w = parseFloat(weight);

    if (!h || !w || h <= 0 || w <= 0) return;

    const heightInMeters = h / 100;
    const bmiValue = parseFloat((w / (heightInMeters * heightInMeters)).toFixed(1));

    let cat = 'Healthy Weight';
    let recService = 'Weight Training & Nutrition Consulting';

    if (bmiValue < 18.5) {
      cat = 'Underweight';
      recService = 'Weight Training & Muscle Hypertrophy Program';
    } else if (bmiValue < 24.9) {
      cat = 'Healthy Weight';
      recService = goal === 'muscle' ? 'Weight Training & CrossFit' : 'Adult Sports & Aerobics';
    } else if (bmiValue < 29.9) {
      cat = 'Overweight';
      recService = 'CrossFit, Aerobics & Nutrition Consulting';
    } else {
      cat = 'Obese';
      recService = 'Personal Training & Nutrition Consulting';
    }

    if (goal === 'flexibility') {
      recService = 'Yoga Classes & Mobility Recovery';
    }

    // Rough formula for ideal weight range at normal BMI 18.5 - 24.9
    const minWeight = (18.5 * heightInMeters * heightInMeters).toFixed(0);
    const maxWeight = (24.9 * heightInMeters * heightInMeters).toFixed(0);

    // Protein suggestion (approx 1.6g - 2.0g per kg for training)
    const proteinTarget = `${Math.round(w * 1.5)}g – ${Math.round(w * 2.0)}g`;

    setResult({
      bmi: bmiValue,
      category: cat,
      idealWeight: `${minWeight}kg – ${maxWeight}kg`,
      recommendedService: recService,
      proteinSuggestion: proteinTarget,
    });
  };

  return (
    <section id="calculator" className="py-20 bg-[#0b0b0e] border-t border-neutral-900 relative">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs uppercase tracking-widest text-red-500 font-semibold mb-2 block">
            Interactive Fitness Assessment
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-heading tracking-tight mb-3">
            BMI &amp; Training Goal Calculator
          </h2>
          <p className="text-neutral-400 text-xs sm:text-sm">
            Enter your height and weight to assess your baseline body mass index and find the ideal VS FITNESS training regimen for your goals.
          </p>
        </div>

        <div className="bg-neutral-900/90 rounded-2xl border border-neutral-800 p-6 sm:p-8 shadow-2xl">
          <form onSubmit={calculateBmi} className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {/* Height input */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                Height (cm)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="100"
                  max="240"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 font-mono"
                  placeholder="e.g. 172"
                  required
                />
                <span className="absolute right-3.5 top-3 text-xs text-neutral-500 font-mono">cm</span>
              </div>
            </div>

            {/* Weight input */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                Weight (kg)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="30"
                  max="250"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 font-mono"
                  placeholder="e.g. 70"
                  required
                />
                <span className="absolute right-3.5 top-3 text-xs text-neutral-500 font-mono">kg</span>
              </div>
            </div>

            {/* Primary Goal */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                Primary Goal
              </label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
              >
                <option value="muscle">Muscle Gain &amp; Strength</option>
                <option value="fatloss">Fat Loss &amp; Conditioning</option>
                <option value="stamina">Athletic Stamina &amp; Sports</option>
                <option value="flexibility">Mobility &amp; Yoga</option>
              </select>
            </div>
          </form>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-neutral-800">
            <button
              type="button"
              onClick={calculateBmi}
              className="inline-flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-red-950/40"
            >
              <Calculator className="w-4 h-4" />
              <span>Calculate My Score</span>
            </button>

            {result && (
              <button
                type="button"
                onClick={() => {
                  setHeight('172');
                  setWeight('70');
                  setResult(null);
                }}
                className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>

          {/* Results Output */}
          {result && (
            <div className="mt-8 p-6 rounded-xl bg-neutral-950 border border-neutral-800 animate-in fade-in duration-300">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="p-3.5 rounded-lg bg-neutral-900 border border-neutral-800">
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1">
                    Your BMI
                  </span>
                  <span className="text-2xl font-extrabold text-white font-mono">
                    {result.bmi}
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-neutral-900 border border-neutral-800">
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1">
                    Category
                  </span>
                  <span className="text-base font-bold text-red-400">
                    {result.category}
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-neutral-900 border border-neutral-800">
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1">
                    Healthy Range
                  </span>
                  <span className="text-sm font-semibold text-neutral-200 font-mono">
                    {result.idealWeight}
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-neutral-900 border border-neutral-800">
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1">
                    Daily Protein Target
                  </span>
                  <span className="text-sm font-semibold text-amber-400 font-mono">
                    {result.proteinSuggestion}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-neutral-900/80 border border-red-900/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-red-400 font-semibold block mb-0.5">
                    Recommended VS FITNESS Focus
                  </span>
                  <p className="text-sm font-bold text-white">
                    {result.recommendedService}
                  </p>
                </div>

                <button
                  onClick={() => onSelectService(result.recommendedService)}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-semibold text-xs rounded-lg transition-colors whitespace-nowrap"
                >
                  <span>Enquire For This Plan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
